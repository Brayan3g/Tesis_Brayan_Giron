% =================================================================
% MT3005 - LABORATORIO 11: Control de robots móviles con ruedas
% -----------------------------------------------------------------
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat. Tome en 
% consideración, sin embargo, que puede que existan ciertas discre-
% pancias en términos de escalamiento para las velocidades y las 
% ganancias de los controladores, ya que la física del robot se
% aproximó de manera sencilla.
% =================================================================
function pololu3pi_controller
addpath('robotat'); % para poder emplear las funciones del Robotat

TIME_STEP = 64;

% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');

% Se configuran y activan el GPS y la brújula
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);

% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
v_max = 800 / 2;

% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 0;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

posy =0;

%-----------------------------------------
% punto de meta:
xg = 0;
yg = 0;
thetag = 0;

%-----------------------------------------------------
% Variables de controlador PID:
% PID orientación
kpO = 1;
kiO = 0.0; 
kdO = 0;

EO = 0;
eO_1 = 0;
% Acercamiento exponencial
v0 = 50;
alpha = 100;

%-------------------------------------------
trayectoria = [
    0.7707    1.2752;
    0.6958    1.2923;
    0.6192    1.2997;
    0.5424    1.2972;
    0.4665    1.2850;
    0.3928    1.2631;
    0.3225    1.2320;
    0.2567    1.1921;
    0.1966    1.1442;
    0.1431    1.0889;
    0.0971    1.0273;
    0.0594    0.9603;
    0.0306    0.8891;
    0.0111    0.8147;
    0.0012    0.7384;
    0.0012    0.6616;
    0.0111    0.5853;
    0.0306    0.5109;
    0.0594    0.4397;
    0.0971    0.3727;
    0.1431    0.3111;
    0.1966    0.2558;
    0.2567    0.2079;
    0.3225    0.1680;
    0.3928    0.1369;
    0.4665    0.1150;
    0.5424    0.1028;
    0.6192    0.1003;
    0.6958    0.1077;
    0.7707    0.1248;
    0.8429    0.1514;
    0.9110    0.1869;
    0.9741    0.2309;
    1.0310    0.2826;
    1.0808    0.3411;
    1.1228    0.4056;
    1.1562    0.4748;
    1.1804    0.5478;
    1.1951    0.6233;
    1.2000    0.7000;
    1.2000    0.7000;
    1.1951    0.7767;
    1.1804    0.8522;
    1.1562    0.9252;
    1.1228    0.9944;
    1.0808    1.0589;
    1.0310    1.1174;
    0.9741    1.1691;
    0.9110    1.2131;
    0.8429    1.2486];
trayectoria = [0,0;
               0,0.5;
               0.5,1;
               1,1.5;
               1.2,2]
iteraciones = length(trayectoria);
n = 1;
%-------------------------------------------
% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1


  % Se obtiene la posición y orientación actual del robot
  pos = wb_gps_get_values(gps);
  mag = wb_compass_get_values(compass);
  posx = pos(1); posy = pos(2);
  bearing = atan2d(mag(2), mag(1)) - 90;
  theta = atan2d(sind(-bearing), cosd(-bearing));
  
  % Se calcula el controlador
  
  if n > iteraciones
        n = 1;
  else
        x_meta = trayectoria(n,:);
        xg = x_meta(1);
        yg = x_meta(2);
  end
  
  % Se calcula el controlador
  %---------------------------------------
  % Controlador Robot 1
  e = [xg - posx; yg - posy];
  thetag = atan2d(e(2), e(1));
  eP = norm(e);
  eO = thetag - theta;
  eO = atan2(sind(eO), cosd(eO));
    
  % Control de velocidad lineal
  kP = v0 * (1 - exp(-alpha*eP^2)) / eP;
  v = kP * eP;

  % Control de velocidad angular
  eO_D = eO - eO_1;
  EO = EO + eO;
  w = kpO * eO + kiO * EO + kdO * eO_D;
  eO_1 = eO;
  %---------------------------------------
  
  % Se mapea del uniciclo de regreso al robot diferencial.
  % OJO: los resultados de estas fórmulas están en rad/s, DEBEN
  % cambiarse a rpm (usar la función auxiliar de conversión)
  %if posy>=1.5
    %v_left = 0;
    %v_right = 0;
  %else

    %v_left = (v - wheel_distance*w)/wheel_radius;
    %v_right = (v + wheel_distance*w)/wheel_radius;
  %end
  % Detener robot si llega a su meta
  if eP < 0.15
        n= n+1;
        if n > iteraciones
          v = 0;
          w =0;
        end
    end
  
  
  v_left = (v - wheel_distance*w)/wheel_radius;
  v_right = (v + wheel_distance*w)/wheel_radius;
  
  v_left = rads2rpm(v_left);
  v_right = rads2rpm(v_right); 
  % Se mapea del uniciclo de regreso al robot diferencial.
  % OJO: los resultados de estas fórmulas están en rad/s, DEBEN
  % cambiarse a rpm (usar la función auxiliar de conversión)
  
  % Se envían las velocidades a los motores de las ruedas (debe
  % garantizarse que estas no superan el valor máximo)
  wb_motor_set_velocity(left_motor, -rpm2rads(velsat(v_left)));
  wb_motor_set_velocity(right_motor, -rpm2rads(velsat(v_right)));
  
  % Flush para gráficos
  drawnow;

end


function qi = invq(q)
    qi = -q;
    qi(1) = q(1);
end
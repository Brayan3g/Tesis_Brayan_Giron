% =================================================================
% MT3005 - LABORATORIO 11: Control de robots móviles con ruedas
% -----------------------------------------------------------------
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat. Tome en 
% consideración, sin embargo, que puede que existan ciertas discre-
% pancias en términos de escalamiento para las velocidades y las 
% ganancias de los controladores, ya que la física del robot se
% aproximó de manera sencilla.
% =================================================================
function pololu3pi_controller
addpath('robotat'); % para poder emplear las funciones del Robotat

TIME_STEP = 64;

% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');

% Se configuran y activan el GPS y la brújula
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);

%--------------------------------------------------------
sen_front = wb_robot_get_device('front')
%sen_back = wb_robot_get_device('back')
%DIS_SENSOR = wb_robot_get_device('distancia');
wb_distance_sensor_enable(sen_front,TIME_STEP);
%wb_distance_sensor_enable(sen_back,TIME_STEP);
%--------------------------------------------------------


% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
% ----------------------------------------------------------
% Parámetros de la simulación
tiempo_simulacion = 50; % Tiempo de simulación en segundos
paso_tiempo = 0.01;      % Tamaño del paso de tiempo en segundos
masa_particula = 1.0;    % Masa de cada partícula
espacio = 2.0;           % Tamaño del espacio a utilizar

% Algunos casos específicos 2D posiblemente interesantes
% Dos partículas a una distancia de 1 
% sin velocidades iniciales
num_particulas = 2;

posiciones = ...
    [0 0 0;...
     0 0 0];

%posiciones = ...
%    [0.5 1 0;...
%     1.5 1 0];


velocidades = ...
    [0 0 0;...
     0 0 0];

aceleraciones = ...
    [0 0 0;...
     0 0 0];


% Parámetros del potencial de Lennard-Jones
%epsilon = 0.4 % Parámetro epsilon (intensidad)
%pureba2:
epsilon = 500;%60; % Parámetro epsilon (intensidad)

sigma = 0.4;   % Parámetro sigma (Alcance)

% Bucle de simulación con el algoritmo de Verlet
num_pasos = tiempo_simulacion / paso_tiempo;
posiciones_ant = posiciones;
%------------------------------------------------------------


v_max = 100;

% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 0;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

posy =0;

%-----------------------------------------
% punto de meta:
xg = 0;
yg = 0;
thetag = 0;

%-----------------------------------------------------
% Variables de controlador PID:
% PID orientación
kpO = 1;
kiO = 0.0; 
kdO = 0;

EO = 0;
eO_1 = 0;
% Acercamiento exponencial
v0 = 50;
alpha = 100;

%-------------------------------------------
trayectoria = [
    0.7707    1.2752;
    0.6958    1.2923;
    0.6192    1.2997;
    0.5424    1.2972;
    0.4665    1.2850;
    0.3928    1.2631;
    0.3225    1.2320;
    0.2567    1.1921;
    0.1966    1.1442;
    0.1431    1.0889;
    0.0971    1.0273;
    0.0594    0.9603;
    0.0306    0.8891;
    0.0111    0.8147;
    0.0012    0.7384;
    0.0012    0.6616;
    0.0111    0.5853;
    0.0306    0.5109;
    0.0594    0.4397;
    0.0971    0.3727;
    0.1431    0.3111;
    0.1966    0.2558;
    0.2567    0.2079;
    0.3225    0.1680;
    0.3928    0.1369;
    0.4665    0.1150;
    0.5424    0.1028;
    0.6192    0.1003;
    0.6958    0.1077;
    0.7707    0.1248;
    0.8429    0.1514;
    0.9110    0.1869;
    0.9741    0.2309;
    1.0310    0.2826;
    1.0808    0.3411;
    1.1228    0.4056;
    1.1562    0.4748;
    1.1804    0.5478;
    1.1951    0.6233;
    1.2000    0.7000;
    1.2000    0.7000;
    1.1951    0.7767;
    1.1804    0.8522;
    1.1562    0.9252;
    1.1228    0.9944;
    1.0808    1.0589;
    1.0310    1.1174;
    0.9741    1.1691;
    0.9110    1.2131;
    0.8429    1.2486];


trayectoria = [0,-0.5;
               0,-0.375;
               0,-0.25;
               0,-0.125;
               0,0.0;
               0,0.125;
               0,0.25;
               0,0.375;
               0,0.5;
               0.125,0.625;
               0.25,0.75;
               0.375,.875;
               0.5,1;
               0.625,1.125;
               0.75,1.25;
               0.875,1.375;
               1,1.5;
               1.125,1.625;
               1.25,1.75;
               1.375,1.875;
               1.2,2];
               
trayectoria = [
    0, -0.5;
    0, -0.4583;
    0, -0.4167;
    0, -0.375;
    0, -0.3333;
    0, -0.2917;
    0, -0.25;
    0, -0.2083;
    0, -0.1667;
    0, -0.125;
    0, -0.0833;
    0, -0.0417;
    0, 0.0;
    0, 0.0417;
    0, 0.0833;
    0, 0.125;
    0, 0.1667;
    0, 0.2083;
    0, 0.25;
    0, 0.2917;
    0, 0.3333;
    0, 0.375;
    0, 0.4167;
    0, 0.4583;
    0, 0.5;
    0.0417, 0.5417;
    0.0833, 0.5833;
    0.125, 0.625;
    0.1667, 0.6667;
    0.2083, 0.7083;
    0.25, 0.75;
    0.2917, 0.7917;
    0.3333, 0.8333;
    0.375, 0.875;
    0.4167, 0.9167;
    0.4583, 0.9583;
    0.5, 1;
    0.5417, 1.0417;
    0.5833, 1.0833;
    0.625, 1.125;
    0.6667, 1.1667;
    0.7083, 1.2083;
    0.75, 1.25;
    0.7917, 1.2917;
    0.8333, 1.3333;
    0.875, 1.375;
    0.9167, 1.4167;
    0.9583, 1.4583;
    1, 1.5;
    1.0417, 1.5417;
    1.0833, 1.5833;
    1.125, 1.625;
    1.1667, 1.6667;
    1.2083, 1.7083;
    1.25, 1.75;
    1.2917, 1.7917;
    1.3333, 1.8333;
    1.375, 1.875;
    1.3167, 1.9167;
    1.2583, 1.9583;
    1.2, 2
];

trayectoria = [
    0, -0.5;
    0, -0.4583;
    0, -0.4167;
    0, -0.375;
    0, -0.3333;
    0, -0.2917;
    0, -0.25;
    0, -0.2083;
    0, -0.1667;
    0, -0.125;
    0, -0.0833;
    0, -0.0417;
    0, 0.0;
    0, 0.0417;
    0, 0.0833;
    0, 0.125;
    0, 0.1667;
    0, 0.2083;
    0, 0.25;
    0, 0.2917;
    0, 0.3333;
    0, 0.375;
    0, 0.4167;
    0, 0.4583;
    0, 0.5;
    0.7707-1.2    1.2752;
    0.6958-1.2    1.2923;
    0.6192-1.2    1.2997;
    0.5424-1.2    1.2972;
    0.4665-1.2    1.2850;
    0.3928-1.2    1.2631;
    0.3225-1.2    1.2320;
    0.2567-1.2    1.1921;
    0.1966-1.2    1.1442;
    0.1431-1.2    1.0889;
    0.0971-1.2    1.0273;
    0.0594-1.2    0.9603;
    0.0306-1.2    0.8891;
    0.0111-1.2    0.8147;
    0.0012-1.2    0.7384;
    0.0012-1.2    0.6616;
    0.0111-1.2    0.5853;
    0.0306-1.2    0.5109;
    0.0594-1.2    0.4397;
    0.0971-1.2    0.3727;
    0.1431-1.2    0.3111;
    0.1966-1.2    0.2558;
    0.2567-1.2    0.2079;
    0.3225-1.2    0.1680;
    0.3928-1.2    0.1369;
    0.4665-1.2    0.1150;
    0.5424-1.2    0.1028;
    0.6192-1.2    0.1003;
    0.6958-1.2    0.1077;
    0.7707-1.2    0.1248;
    0.8429-1.2    0.1514;
    0.9110-1.2    0.1869;
    0.9741-1.2    0.2309;
    1.0310-1.2    0.2826;
    1.0808-1.2    0.3411;
    1.1228-1.2    0.4056;
    1.1562-1.2    0.4748;
    1.1804-1.2    0.5478;
    1.1951-1.2    0.6233;
    1.2000-1.2    0.7000;
    1.2000-1.2    0.7000;
    1.1951-1.2    0.7767;
    1.1804-1.2    0.8522;
    1.1562-1.2    0.9252;
    1.1228-1.2    0.9944;
    1.0808-1.2    1.0589;
    1.0310-1.2    1.1174;
    0.9741-1.2    1.1691;
    0.9110-1.2    1.2131;
    0.8429-1.2    1.2486];

trayectoria = [
    0.5000    1.2000;
    0.4167    1.2000;
    0.3333    1.2000;
    0.2500    1.2000;
    0.1667    1.2000;
    0.0000    0.8000;
    0.0000    0.6000;
    0.0000    0.4000;
    0.0000    0.2000;
    0.0000         0;
    0.0000   -0.2000;
    0.0000   -0.4000;
    0.0000   -0.6000;
    0.1667   -1.2000;
    0.2500   -1.2000;
    0.3333   -1.2000;
    0.4167   -1.2000;
    0.5000   -1.2000;
    0.5833   -1.2000;
    0.6667   -1.2000;
    0.7500   -1.2000;
    0.8333   -1.2000;
    1.0000   -0.8000;
    1.0000   -0.6000;
    1.0000   -0.4000;
    1.0000   -0.2000;
    1.0000         0;
    1.0000    0.2000;
    1.0000    0.4000;
    1.0000    0.6000;
    1.0000    0.8000;
    0.8333    1.2000;
    0.7500    1.2000;
    0.6667    1.2000;
    0.5833    1.2000;
];

               
               
iteraciones = length(trayectoria);
n = 1;

%-----------------------------------------------
% Inicialización de variables
intervalo = 0.25;%0.5;%0.75;%1;  % Intervalo de tiempo en segundos
t_inicio = tic;  % Registrar el tiempo inicial
indice = 1;  % Inicializar el índice para recorrer las filas del arreglo

%-------------------------------------------
% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1

  tic;
  % Se obtiene la posición y orientación actual del robot
  pos = wb_gps_get_values(gps);
  mag = wb_compass_get_values(compass);
  posx = pos(1); posy = pos(2);
  bearing = atan2d(mag(2), mag(1)) - 90;
  theta = atan2d(sind(-bearing), cosd(-bearing));
  
  
  dis_front = (wb_distance_sensor_get_value(sen_front));
  dis_front = dis_front*(3/20);
  y_2 = posy + 0.15 + (dis_front/100);

  posiciones = ...
    [y_2, 0, 0;...
     posy, posx, 0];
  %-------------------------------------------------------
  % Verificar si han pasado 5 segundos
    if toc(t_inicio) >= intervalo
        % Asignar la fila actual del arreglo al vector_actual
        %vector_actual = arreglo(indice, :);
        
        posiciones(1,1) = trayectoria(indice,2)  % Actualizamos el vector
        posiciones(1,2) = trayectoria(indice,1)  % Actualizamos el vector

        fprintf('Tiempo: %d segundos - Vector actualizado a: [%f, %f]\n', indice*intervalo, posiciones(1), posiciones(2));

        % Incrementar el índice para la siguiente fila
        indice = indice + 1;
        
        if indice> length(trayectoria);
            break;
        end
        % Reiniciar el temporizador
        t_inicio = tic;
    end
  %-------------------------------------------------------  
  
  
          
  posiciones_ant = posiciones
  fuerzas = zeros(num_particulas,2);

%----------------------------------------------------------------------
    
  % Se calcula el controlador
  
  if n > iteraciones
        n = 1;
  else
        x_meta = trayectoria(n,:);
        xg = x_meta(1);
        yg = x_meta(2);
  end
  
  % Se calcula el controlador
  %---------------------------------------
  % Controlador Robot 1
  e = [xg - posx; yg - posy];
  thetag = atan2d(e(2), e(1));
  eP = norm(e);
  eO = thetag - theta;
  eO = atan2(sind(eO), cosd(eO));
    
  % Control de velocidad lineal
  kP = v0 * (1 - exp(-alpha*eP^2)) / eP;
  %v = kP * eP;
  %v= 0

  % Control de velocidad angular
  eO_D = eO - eO_1;
  EO = EO + eO;
  w = kpO * eO + kiO * EO + kdO * eO_D;
  eO_1 = eO;
  %---------------------------------------
  num_particulas = size(posiciones_ant, 1);
  dimension = size(posiciones_ant, 2);
  fuerzas = zeros(num_particulas, dimension);
  for i = 1:num_particulas
        for j = i+1:num_particulas
            % Calcula el vector entre las partículas
            r_ij = posiciones_ant(i, :) - posiciones_ant(j, :);
            % Calcular la distancia entre particulas
            r = norm(r_ij);       
            
            % Calcular la fuerza 
            fuerza_ij = 24*epsilon*( 2*(sigma/r)^12 - (sigma/r)^6 )*r_ij/r^2;
                %epsilon*((sigma/r)^12 - 1.3*(sigma/r)^6 )*r_ij/r^2;

            % Aplicar la fuerza a ambas partículas (ley de acción y reacción)
            fuerzas(i, :) = fuerzas(i, :) + fuerza_ij;
            fuerzas(j, :) = fuerzas(j, :) - fuerza_ij;
        end
    end
%------------------------------------------------------------------------------------------------    
    
    
    % Calcular aceleraciones
    aceleraciones = fuerzas / masa_particula;
    
   % Actualizar velocidades utilizando el algoritmo de Verlet
    velocidades = velocidades + (aceleraciones * paso_tiempo)
        
    if velocidades(4) < 0
      velocidades(4) = 0;
    end
    
    if velocidades(2) < 0
      velocidades(2) = 0;
    end
    vcom2 = velocidades(2)
    vcom = velocidades(4)
    %v = (velocidades(4))*v_max
    v = norm(velocidades(4)+velocidades(2))

  %----------------------------------------------
  % Se mapea del uniciclo de regreso al robot diferencial.
  % OJO: los resultados de estas fórmulas están en rad/s, DEBEN
  % cambiarse a rpm (usar la función auxiliar de conversión)
  %if posy>=1.5
    %v_left = 0;
    %v_right = 0;
  %else

    %v_left = (v - wheel_distance*w)/wheel_radius;
    %v_right = (v + wheel_distance*w)/wheel_radius;
  %end
  % Detener robot si llega a su meta
  if eP < 0.15
        n= n+1;
        if n > iteraciones
          v = 0;
          w =0;
        end
    end
  
  
  v_left = (v - wheel_distance*w)/wheel_radius;
  v_right = (v + wheel_distance*w)/wheel_radius;
  
  v_left = rads2rpm(v_left);
  v_right = rads2rpm(v_right); 
  % Se mapea del uniciclo de regreso al robot diferencial.
  % OJO: los resultados de estas fórmulas están en rad/s, DEBEN
  % cambiarse a rpm (usar la función auxiliar de conversión)
  
  % Se envían las velocidades a los motores de las ruedas (debe
  % garantizarse que estas no superan el valor máximo)
  wb_motor_set_velocity(left_motor, -rpm2rads(velsat(v_left)));
  wb_motor_set_velocity(right_motor, -rpm2rads(velsat(v_right)));
  
  % Flush para gráficos
  drawnow;

end


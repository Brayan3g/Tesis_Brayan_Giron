% =================================================================
% MT3005 - LABORATORIO 11: Control de robots móviles con ruedas
% -----------------------------------------------------------------
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat. Tome en 
% consideración, sin embargo, que puede que existan ciertas discre-
% pancias en términos de escalamiento para las velocidades y las 
% ganancias de los controladores, ya que la física del robot se
% aproximó de manera sencilla.
% =================================================================
function pololu3pi_controller
addpath('robotat'); % para poder emplear las funciones del Robotat

TIME_STEP = 64;

% ----------------------------------------------------------
% Parámetros de la simulación
tiempo_simulacion = 50; % Tiempo de simulación en segundos
paso_tiempo = 0.01;      % Tamaño del paso de tiempo en segundos
masa_particula = -1.0;    % Masa de cada partícula
espacio = 2.0;           % Tamaño del espacio a utilizar

% Algunos casos específicos 2D posiblemente interesantes
% Dos partículas a una distancia de 1 
% sin velocidades iniciales
num_particulas = 2;

posiciones = ...
    [1 1 0;...
     1.5 1 0];

%posiciones = ...
%    [0.5 1 0;...
%     1.5 1 0];


velocidades = ...
    [0 0 0;...
     0 0 0];

aceleraciones = ...
    [0 0 0;...
     0 0 0];


% Matrices para almacenar las coordenadas de posición de cada partícula 
% a lo largo del tiempo
%trayectorias_x_acum = ...
%    zeros(num_particulas, tiempo_simulacion / paso_tiempo);
%trayectorias_y_acum = ...
%    zeros(num_particulas, tiempo_simulacion / paso_tiempo);
%trayectorias_z_acum = ...
%    zeros(num_particulas, tiempo_simulacion / paso_tiempo);

% Parámetros del potencial de Lennard-Jones
%epsilon = 0.4 % Parámetro epsilon (intensidad)
%pureba2:
epsilon = 50 %0.3 % Parámetro epsilon (intensidad)

sigma = 0.4;   % Parámetro sigma (Alcance)

% Bucle de simulación con el algoritmo de Verlet
num_pasos = tiempo_simulacion / paso_tiempo;
posiciones_ant = posiciones;




%------------------------------------------------------------


% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');

% Se configuran y activan el GPS y la brújula
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);


%--------------------------------------------------------
sen_front = wb_robot_get_device('front')
%sen_back = wb_robot_get_device('back')
%DIS_SENSOR = wb_robot_get_device('distancia');
wb_distance_sensor_enable(sen_front,TIME_STEP);
%wb_distance_sensor_enable(sen_back,TIME_STEP);

%--------------------------------------------------------


% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
%v_max = 800 / 2;
v_max = 3;
velocidad_maxima = 4.5;
% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 0;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

%-----------------------------------------
% punto de meta:
xg = 0;
yg = 0;
thetag = 0;

%-----------------------------------------------------
% Variables de controlador PID:
% PID orientación
kpO = 1;
kiO = 0.0; 
kdO = 0;

EO = 0;
eO_1 = 0;
% Acercamiento exponencial
v0 = 100;
alpha = 100;

%-------------------------------------------
trayectoria = [
    0.7707    1.2752;
    0.6958    1.2923;
    0.6192    1.2997;
    0.5424    1.2972;
    0.4665    1.2850;
    0.3928    1.2631;
    0.3225    1.2320;
    0.2567    1.1921;
    0.1966    1.1442;
    0.1431    1.0889;
    0.0971    1.0273;
    0.0594    0.9603;
    0.0306    0.8891;
    0.0111    0.8147;
    0.0012    0.7384;
    0.0012    0.6616;
    0.0111    0.5853;
    0.0306    0.5109;
    0.0594    0.4397;
    0.0971    0.3727;
    0.1431    0.3111;
    0.1966    0.2558;
    0.2567    0.2079;
    0.3225    0.1680;
    0.3928    0.1369;
    0.4665    0.1150;
    0.5424    0.1028;
    0.6192    0.1003;
    0.6958    0.1077;
    0.7707    0.1248;
    0.8429    0.1514;
    0.9110    0.1869;
    0.9741    0.2309;
    1.0310    0.2826;
    1.0808    0.3411;
    1.1228    0.4056;
    1.1562    0.4748;
    1.1804    0.5478;
    1.1951    0.6233;
    1.2000    0.7000;
    1.2000    0.7000;
    1.1951    0.7767;
    1.1804    0.8522;
    1.1562    0.9252;
    1.1228    0.9944;
    1.0808    1.0589;
    1.0310    1.1174;
    0.9741    1.1691;
    0.9110    1.2131;
    0.8429    1.2486];

iteraciones = length(trayectoria);
n = 1;
%eO = 10;
%__________________________________________________________________________
% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1

%----------------------------------------------------------------------
  % Se obtiene la posición y orientación actual del robot
  pos = wb_gps_get_values(gps);
  mag = wb_compass_get_values(compass);
  posx = pos(1); posy = pos(2);
  bearing = atan2d(mag(2), mag(1)) - 90;
  theta = atan2d(sind(-bearing), cosd(-bearing));
  
  if n > iteraciones
        n = 1;
  else
        x_meta = trayectoria(n,:)
        xg = x_meta(1);
        yg = x_meta(2);
  end
    
  
  dis_front = (wb_distance_sensor_get_value(sen_front));
  dis_front = dis_front*(3/20);
  y_2 = posy + 0.15 + (dis_front/100);
  
  
  posiciones = ...
    [posy 1 0;...
     y_2 1 0];

%----------------------------------------------------------------------
  
  % Se calcula el controlador
  %---------------------------------------
  % Controlador Robot 1
  e = [xg - posx; yg - posy];
  thetag = atan2d(e(2), e(1));
  eP = norm(e);
  eO = thetag - theta;
  eO = atan2(sind(eO), cosd(eO));
    
  % Control de velocidad lineal
  %kP = v0 * (1 - exp(-alpha*eP^2)) / eP;
  %v = kP * eP;

  % Control de velocidad angular
  eO_D = eO - eO_1;
  EO = EO + eO;
  w = kpO * eO + kiO * EO + kdO * eO_D;
  eO_1 = eO;
      
  if abs(w) < 3
      w = 0;     
  end 
  
  if eP < 0.15
        n= n+1;
        if n > iteraciones
          v = 0;
          w =0;
        end
    end
  %---------------------------------------

%------------------------------------------------------------------------------------------------
% Función para calcular las fuerzas entre partículas (utilizando el potencial de Lennard-Jones)
    num_particulas = size(posiciones_ant, 1);
    dimension = size(posiciones_ant, 2);
    fuerzas = zeros(num_particulas, dimension);
    
    
    for i = 1:num_particulas
        for j = i+1:num_particulas
            % Calcula el vector entre las partículas
            r_ij = posiciones_ant(i, :) - posiciones_ant(j, :);
            % Calcular la distancia entre particulas
            r = norm(r_ij);       
            
            % Calcular la fuerza 
            fuerza_ij = ...
                epsilon*((sigma/r)^12 - 1.3*(sigma/r)^6 )*r_ij/r^2;
                %24*epsilon*( 2*(sigma/r)^12 - (sigma/r)^6 )*r_ij/r^2;
                
            
            % Aplicar la fuerza a ambas partículas (ley de acción y reacción)
            fuerzas(i, :) = fuerzas(i, :) + fuerza_ij;
            fuerzas(j, :) = fuerzas(j, :) - fuerza_ij;
        end
    end
%------------------------------------------------------------------------------------------------    
    
    
    % Calcular aceleraciones
    aceleraciones = fuerzas / masa_particula;
    
   % Actualizar velocidades utilizando el algoritmo de Verlet
    velocidades = velocidades + (aceleraciones * paso_tiempo);
        
    if velocidades(1) < 0
      velocidades(1) = 0;
    else 
      velocidades(1) = velocidades(1);
    end
      
    % Actualizar posiciones utilizando el algoritmo de Verlet
    %posiciones = ...
        %posiciones + (velocidades * paso_tiempo) ...
        %+ (0.5 * aceleraciones * paso_tiempo^2);
    posiciones = ...
    [posy 1 0;...
     y_2 1 0];

     % Verificar colisiones con las paredes
    %for i = 1:num_particulas
        %for dim = 1:3
            %if posiciones(i, dim) < 0 || posiciones(i, dim) > espacio
                % Invertir la velocidad en la dimensión correspondiente
                %velocidades(i, dim) = -velocidades(i, dim);
            %end
        %end
    %end

    % Almacenar las coordenadas de posición de cada partícula 
    % en este paso de tiempo
    %trayectorias_x_acum(:, paso) = posiciones(:, 1);
    %trayectorias_y_acum(:, paso) = posiciones(:, 2);
    %trayectorias_z_acum(:, paso) = posiciones(:, 3);
    
    % Actualizar posiciones y aceleraciones para el siguiente 
    % paso de tiempo
    posiciones_ant = posiciones;
  %end

%---------------------------------------------------------------------- 
 % v_left = (velocidades(1) - wheel_distance*w)/wheel_radius;
 %v_right = (velocidades(1) + wheel_distance*w)/wheel_radius;
  %v = velocidades(1)
  v = (velocidades(1))*v_max 
  %v =0;
  %v_left = (velocidades(1))*v_max; 
  %v_right = v_left;
  
  v_left = (v - wheel_distance*w)/wheel_radius;
  v_right = (v + wheel_distance*w)/wheel_radius;
  
  v_left = rads2rpm(v_left);
  v_right = rads2rpm(v_right);
  %v_left = (v - wheel_distance*w)/wheel_radius;
  %v_right = (v + wheel_distance*w)/wheel_radius;  
  
  % Limite de velocidad
  %v_left = max(min(v_left, velocidad_maxima), -velocidad_maxima);
  %v_right = max(min(v_right, velocidad_maxima), -velocidad_maxima);

  v_left = min(v_left, velocidad_maxima);
  v_right = min(v_right, velocidad_maxima);

  
  %v_left = rads2rpm(v_left);
  %v_right = rads2rpm(v_right); 

  
  % Se envían las velocidades a los motores de las ruedas (debe
  % garantizarse que estas no superan el valor máximo)
  wb_motor_set_velocity(left_motor, velsat(v_left));
  wb_motor_set_velocity(right_motor, velsat(v_right));

  % Flush para gráficos
  
  %plot(posy, posx, 'g.'); % Punto rojo
  %hold on;
  %plot(y_2,posx, 'r.'); % Punto azul
  %%hold on;
  %%plot(x, y_3, 'b.'); % Punto azul
  %hold off;
  %axis([-2.0 2.0  -2.5 2.5]);
  %title('Posición Planar (x, y)')
  %xlabel('X');
  %ylabel('Y');     
 
  
  
  drawnow;

  


% cleanup code goes here: write data to files, etc.
end

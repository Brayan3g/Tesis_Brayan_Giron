% =================================================================
% MT3005 - LABORATORIO 11: Control de robots móviles con ruedas
% -----------------------------------------------------------------
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat. Tome en 
% consideración, sin embargo, que puede que existan ciertas discre-
% pancias en términos de escalamiento para las velocidades y las 
% ganancias de los controladores, ya que la física del robot se
% aproximó de manera sencilla.
% =================================================================
function pololu3pi_controller
addpath('robotat'); % para poder emplear las funciones del Robotat

TIME_STEP = 64;

% ----------------------------------------------------------
% Parámetros de la simulación
tiempo_simulacion = 50; % Tiempo de simulación en segundos
paso_tiempo = 0.01;      % Tamaño del paso de tiempo en segundos
masa_particula = -1.0;    % Masa de cada partícula
espacio = 2.0;           % Tamaño del espacio a utilizar

% Algunos casos específicos 2D posiblemente interesantes
% Dos partículas a una distancia de 1 
% sin velocidades iniciales
num_particulas = 2;

posiciones = ...
    [1 1 0;...
     1.5 1 0];

%posiciones = ...
%    [0.5 1 0;...
%     1.5 1 0];


velocidades = ...
    [0 0 0;...
     0 0 0];

aceleraciones = ...
    [0 0 0;...
     0 0 0];


% Matrices para almacenar las coordenadas de posición de cada partícula 
% a lo largo del tiempo
%trayectorias_x_acum = ...
%    zeros(num_particulas, tiempo_simulacion / paso_tiempo);
%trayectorias_y_acum = ...
%    zeros(num_particulas, tiempo_simulacion / paso_tiempo);
%trayectorias_z_acum = ...
%    zeros(num_particulas, tiempo_simulacion / paso_tiempo);

% Parámetros del potencial de Lennard-Jones
%epsilon = 0.4 % Parámetro epsilon (intensidad)
%pureba2:
epsilon = 0.18; %0.2; % Parámetro epsilon (intensidad)

sigma = 0.4;   % Parámetro sigma (Alcance)

% Bucle de simulación con el algoritmo de Verlet
num_pasos = tiempo_simulacion / paso_tiempo;
posiciones_ant = posiciones;


%------------------------------------------------------------


% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');

% Se configuran y activan el GPS y la brújula
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);


%--------------------------------------------------------
sen_front = wb_robot_get_device('front')
%sen_back = wb_robot_get_device('back')
%DIS_SENSOR = wb_robot_get_device('distancia');
wb_distance_sensor_enable(sen_front,TIME_STEP);
%wb_distance_sensor_enable(sen_back,TIME_STEP);

%--------------------------------------------------------


% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
%v_max = 800 / 2;
v_max = 3;
velocidad_maxima = 0.6;
% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 0;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

%__________________________________________________________________________
% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1

%----------------------------------------------------------------------
  % Se obtiene la posición y orientación actual del robot
  pos = wb_gps_get_values(gps);
  mag = wb_compass_get_values(compass);
  posx = pos(1); posy = pos(2);
  bearing = atan2d(mag(2), mag(1)) - 90;
  theta = atan2d(sind(-bearing), cosd(-bearing));
  
  
  dis_front = (wb_distance_sensor_get_value(sen_front));
  dis_front = dis_front*(3/20);
  y_2 = posy + 0.15 + (dis_front/100);
  %y_3 = posy - 0.15 - (dis_front/100);
  %y_all = [ posy,y_2,y_3];
%----------------------------------------------------------------------
  
  % Se calcula el controlador
  %for paso = 1:5000
    % Calcular fuerzas entre partículas    
    %fuerzas = calcular_fuerza(posiciones_ant, epsilon, sigma);
%------------------------------------------------------------------------------------------------
% Función para calcular las fuerzas entre partículas (utilizando el potencial de Lennard-Jones)
    num_particulas = size(posiciones_ant, 1);
    dimension = size(posiciones_ant, 2);
    fuerzas = zeros(num_particulas, dimension);
    
    for i = 1:num_particulas
        for j = i+1:num_particulas
            % Calcula el vector entre las partículas
            r_ij = posiciones_ant(i, :) - posiciones_ant(j, :);
            % Calcular la distancia entre particulas
            r = norm(r_ij);       
            
            % Calcular la fuerza 
            fuerza_ij = ...
                epsilon*((sigma/r)^12 - 1.3*(sigma/r)^6 )*r_ij/r^2;
                %24*epsilon*( 2*(sigma/r)^12 - (sigma/r)^6 )*r_ij/r^2;
                
            
            % Aplicar la fuerza a ambas partículas (ley de acción y reacción)
            fuerzas(i, :) = fuerzas(i, :) + fuerza_ij;
            fuerzas(j, :) = fuerzas(j, :) - fuerza_ij;
        end
    end
%------------------------------------------------------------------------------------------------    
    
    
    % Calcular aceleraciones
    aceleraciones = fuerzas / masa_particula;
    
   % Actualizar velocidades utilizando el algoritmo de Verlet
    velocidades = velocidades + (aceleraciones * paso_tiempo);
    
    % Actualizar posiciones utilizando el algoritmo de Verlet
    %posiciones = ...
        %posiciones + (velocidades * paso_tiempo) ...
        %+ (0.5 * aceleraciones * paso_tiempo^2);
    posiciones = ...
    [posy 1 0;...
     y_2 1 0];

     % Verificar colisiones con las paredes
    %for i = 1:num_particulas
        %for dim = 1:3
            %if posiciones(i, dim) < 0 || posiciones(i, dim) > espacio
                % Invertir la velocidad en la dimensión correspondiente
                %velocidades(i, dim) = -velocidades(i, dim);
            %end
        %end
    %end

    % Almacenar las coordenadas de posición de cada partícula 
    % en este paso de tiempo
    %trayectorias_x_acum(:, paso) = posiciones(:, 1);
    %trayectorias_y_acum(:, paso) = posiciones(:, 2);
    %trayectorias_z_acum(:, paso) = posiciones(:, 3);
    
    % Actualizar posiciones y aceleraciones para el siguiente 
    % paso de tiempo
    posiciones_ant = posiciones;
  %end

%---------------------------------------------------------------------- 
 % v_left = (velocidades(1) - wheel_distance*w)/wheel_radius;
 %v_right = (velocidades(1) + wheel_distance*w)/wheel_radius;

  v_left = (velocidades(1))*v_max; 
  v_right = v_left;  
  % Limite de velocidad
  v_left = max(min(v_left, velocidad_maxima), -velocidad_maxima);
  v_right = max(min(v_right, velocidad_maxima), -velocidad_maxima);

  
  %v_left = rads2rpm(v_left);
  %v_right = rads2rpm(v_right); 

  
  % Se envían las velocidades a los motores de las ruedas (debe
  % garantizarse que estas no superan el valor máximo)
  wb_motor_set_velocity(left_motor, velsat(v_left));
  wb_motor_set_velocity(right_motor, velsat(v_right));

  % Flush para gráficos
  
  %plot(posy, posx, 'g.'); % Punto rojo
  %hold on;
  %plot(y_2,posx, 'r.'); % Punto azul
  %hold on;
  %plot(x, y_3, 'b.'); % Punto azul
  %hold off;
  %axis([-2.0 2.0  -2.5 2.5]);
  %title('Posición Planar (x, y)')
  %xlabel('X');
  %ylabel('Y');     
 
  
  
  drawnow;

  


% cleanup code goes here: write data to files, etc.
end

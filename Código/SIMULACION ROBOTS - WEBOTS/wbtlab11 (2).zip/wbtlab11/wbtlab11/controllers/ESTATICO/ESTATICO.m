% =================================================================
% MT3005 - LABORATORIO 11: Control de robots móviles con ruedas
% -----------------------------------------------------------------
% Esta simulación busca ser un entorno representativo de la 
% situación real de un Pololu 3Pi dentro del Robotat. Tome en 
% consideración, sin embargo, que puede que existan ciertas discre-
% pancias en términos de escalamiento para las velocidades y las 
% ganancias de los controladores, ya que la física del robot se
% aproximó de manera sencilla.
% =================================================================
function pololu3pi_controller
addpath('robotat'); % para poder emplear las funciones del Robotat

TIME_STEP = 64;

% Dimensiones del robot
wheel_radius = 32; % mm
wheel_distance = 96 - 2*6.8; % mm

% Se obtienen los device tags/handles
right_motor = wb_robot_get_device('motor_1');
left_motor = wb_robot_get_device('motor_2');
compass = wb_robot_get_device('compass');
gps = wb_robot_get_device('gps');

% Se configuran y activan el GPS y la brújula
wb_gps_enable(gps, 10);
wb_compass_enable(compass, 10);

% Velocidad máxima, en rpm, de cada una de las ruedas. Se coloca de 
% esta manera ya que si bien la velocidad máxima admisible por los
% motores es de 800 rpm, por seguridad esta se limitará a la mitad. 
v_max = 800 / 2;

% Variables para las velocidades de las ruedas (en rpm <- OJO)
v_left = 0;
v_right = 0;

% Funciones de conversión entre rpm y rad/s para cambiar entre las
% dimensionales del robot y el simulador
rads2rpm = @(x) x * ( 60 / (2*pi));
rpm2rads = @(x) x * ( 2*pi / 60);

% Función de saturación para garantizar que las velocidades se
% encuentren en el rango adecuado
velsat = @(vel) sign(vel) * min(abs(vel), v_max);

% Se inicializan los motores
wb_motor_set_position(left_motor, inf);
wb_motor_set_position(right_motor, inf);
wb_motor_set_velocity(left_motor, 0.0);
wb_motor_set_velocity(right_motor, 0.0);

posy =0;
% Ciclo de simulación
while wb_robot_step(TIME_STEP) ~= -1


  % Se obtiene la posición y orientación actual del robot
  pos = wb_gps_get_values(gps);
  mag = wb_compass_get_values(compass);
  posx = pos(1); posy = pos(2)
  bearing = atan2d(mag(2), mag(1)) - 90;
  theta = atan2d(sind(-bearing), cosd(-bearing));
  
  % Se calcula el controlador
  
  % Se mapea del uniciclo de regreso al robot diferencial.
  % OJO: los resultados de estas fórmulas están en rad/s, DEBEN
  % cambiarse a rpm (usar la función auxiliar de conversión)
  if posy>=1.5
    v_left = 0;
    v_right = 0;
  else
    v = 200;
    w = 0;
    v_left = (v - wheel_distance*w)/wheel_radius;
    v_right = (v + wheel_distance*w)/wheel_radius;
  end
 % v_left = rads2rpm(v_left);
 % v_right = rads2rpm(v_right); 
  % Se envían las velocidades a los motores de las ruedas (debe
  % garantizarse que estas no superan el valor máximo)
  v_right =0;
  v_left =0 ;
  wb_motor_set_velocity(left_motor, -rpm2rads(velsat(v_left)));
  wb_motor_set_velocity(right_motor, -rpm2rads(velsat(v_right)));

  % Flush para gráficos
  drawnow;

end

